﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using HotelManagement.Models;
using HotelManagement.Controllers;



namespace UnitTestHotelStaff
{
    [TestClass] ///For Housekeeping Unit Test
    public class UnitTestHouseKeepingController
    {
        /////////************************RETRIEVE
        [TestMethod]
        public void GetAllStaffList_ShouldReturnAllList()
        {
            var controller = new HouseKeepingController();
            var result = controller.StaffLists();
            Assert.IsNotNull(result);
        }
        ////////************************DELETE
        [TestMethod]
        public void DeleteStaff_ShouldBeSuccessful()
        {
            string idtobedeleted = "099a8da9-54b7-46aa-85fe-26d1bae581c7"; ///Used ID
            ///The ID above have been deleted, so get a new one if
            /// This test is to be replicated
            var controller = new HouseKeepingController();
            var result = controller.DeleteStaff(idtobedeleted);
            Assert.IsNotNull(result);
        }
        ///////************************UPDATE
        [TestMethod]
        public void UpdateStaff()
        {
            string id = "fde90a7e-5125-48a7-8789-d5a851ca52bd";//ID to be edited
            var controller = new HouseKeepingController();
            var result = controller.EditStaff(id); ///Along with other parameters of what is to be edited
                                                   ///Add code of what is to be edited
            Assert.IsNotNull(result);
        }

        //////*****************************CREATE
        [TestMethod]
        public void CreateStaff()
        {
            string FirstName = "Testing";
            string LastName = "User";
            string UserName = "TestingUnitUser";
            RegisterViewModel m = new RegisterViewModel();
            m.FirstName = FirstName;
            m.LastName = LastName;
            m.UserName = UserName;
            var controller = new AccountController();
            var result = controller.Register(m);
            Assert.IsNotNull(result);
        }
    }
}
