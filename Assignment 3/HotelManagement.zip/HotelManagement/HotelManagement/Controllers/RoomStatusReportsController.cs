﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HotelManagement.Models;

namespace HotelManagement.Controllers
{
    public class RoomStatusReportsController : Controller
    {
        private HotelReportDataEntities db = new HotelReportDataEntities();

        // GET: RoomStatusReports
        public ActionResult Index()
        {
            return View(db.RoomStatusReports.ToList());
        }

        // GET: RoomStatusReports/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomStatusReport roomStatusReport = db.RoomStatusReports.Find(id);
            if (roomStatusReport == null)
            {
                return HttpNotFound();
            }
            return View(roomStatusReport);
        }

        // GET: RoomStatusReports/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: RoomStatusReports/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "RoomNumber,TypesOfRooms,Status")] RoomStatusReport roomStatusReport)
        {
            if (ModelState.IsValid)
            {
                db.RoomStatusReports.Add(roomStatusReport);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(roomStatusReport);
        }

        // GET: RoomStatusReports/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomStatusReport roomStatusReport = db.RoomStatusReports.Find(id);
            if (roomStatusReport == null)
            {
                return HttpNotFound();
            }
            return View(roomStatusReport);
        }

        // POST: RoomStatusReports/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "RoomNumber,TypesOfRooms,Status")] RoomStatusReport roomStatusReport)
        {
            if (ModelState.IsValid)
            {
                db.Entry(roomStatusReport).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(roomStatusReport);
        }

        // GET: RoomStatusReports/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomStatusReport roomStatusReport = db.RoomStatusReports.Find(id);
            if (roomStatusReport == null)
            {
                return HttpNotFound();
            }
            return View(roomStatusReport);
        }

        // POST: RoomStatusReports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RoomStatusReport roomStatusReport = db.RoomStatusReports.Find(id);
            db.RoomStatusReports.Remove(roomStatusReport);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
