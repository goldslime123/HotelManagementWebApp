﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HotelManagement.Controllers
{
    public class RoomController : Controller
    {
        // GET: Hotel
        public ActionResult DisplayAllRooms()
        {
            return View();
        }

        public ActionResult RoomList()
        {
            return View();
        }


        public ActionResult Create()
        {
            return View();
        }








    }
}