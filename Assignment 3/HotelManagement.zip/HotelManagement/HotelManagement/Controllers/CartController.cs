﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using HotelManagement.Models;
using System.Windows.Forms;
using Microsoft.AspNet.Identity.EntityFramework;

namespace HotelManagement.Controllers
{
    public class CartController : Controller
    {


        private ApplicationSignInManager _signInManager;
        private ApplicationUserManager _userManager;
        private ApplicationDbContext context;

        public CartController()
        {
            context = new ApplicationDbContext();
        }

        public CartController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set
            {
                _signInManager = value;
            }
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }
     

        // GET: /Booking/CheckinGuest
        [AllowAnonymous]
        public ActionResult CheckOutPage()
        {
            ViewBag.Name = new SelectList(context.Roles.ToList(), "Name", "Name");
            return View();
        }


        // POST: /Booking/CheckinGuest
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CheckOutPage(CheckoutViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser
                {
                    UserName = model.UserName,
                    Checkin = model.Checkin,
                    Checkout = model.Checkout,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    NumberofAdults = model.NumberofAdults,
                    NumberofChildren = model.NumberofChildren,
                    PhoneNumber = model.PhoneNumber,
                    Email = model.Email,
                    HomeAddress = model.HomeAddress,
                    CreditCardNumber = model.CreditCardNumber,
                    ExpiryDate = model.ExpiryDate,
                    TypesofPayment = model.TypesofPayment,
                    TotalAmount = model.TotalAmount,
                   
                    RoomNumber = model.RoomNumber,
                    RoomTypes = model.RoomTypes,
                    Comment=model.Comment
                };
                var result = await UserManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {


                    //Assign Role to user Here
                    await UserManager.AddToRoleAsync(user.Id, model.Role);
                    //Ends Here

                    string text = "Booking Successful and Thank You for the Feedback!";
                    MessageBox.Show(text);
                }
                AddErrors(result);

            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }
        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }
    }
}