namespace HotelManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CustomFields : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AspNetUsers", "FirstName", c => c.String());
            AddColumn("dbo.AspNetUsers", "LastName", c => c.String());
            AddColumn("dbo.AspNetUsers", "NumberofAdults", c => c.Int(nullable: false));
            AddColumn("dbo.AspNetUsers", "NumberofChildren", c => c.Int(nullable: false));
            AddColumn("dbo.AspNetUsers", "HomeAddress", c => c.String());
            AddColumn("dbo.AspNetUsers", "TypesofPayment", c => c.String());
            AddColumn("dbo.AspNetUsers", "Checkin", c => c.String());
            AddColumn("dbo.AspNetUsers", "Checkout", c => c.String());
            AddColumn("dbo.AspNetUsers", "DOB", c => c.String());
            AddColumn("dbo.AspNetUsers", "BankNumber", c => c.Int(nullable: false));
            AddColumn("dbo.AspNetUsers", "DutyTypes", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.AspNetUsers", "DutyTypes");
            DropColumn("dbo.AspNetUsers", "BankNumber");
            DropColumn("dbo.AspNetUsers", "DOB");
            DropColumn("dbo.AspNetUsers", "Checkout");
            DropColumn("dbo.AspNetUsers", "Checkin");
            DropColumn("dbo.AspNetUsers", "TypesofPayment");
            DropColumn("dbo.AspNetUsers", "HomeAddress");
            DropColumn("dbo.AspNetUsers", "NumberofChildren");
            DropColumn("dbo.AspNetUsers", "NumberofAdults");
            DropColumn("dbo.AspNetUsers", "LastName");
            DropColumn("dbo.AspNetUsers", "FirstName");
        }
    }
}
