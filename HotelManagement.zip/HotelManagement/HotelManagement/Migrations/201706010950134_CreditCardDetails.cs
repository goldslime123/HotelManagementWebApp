namespace HotelManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreditCardDetails : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AspNetUsers", "CreditCardNumber", c => c.String());
            AddColumn("dbo.AspNetUsers", "ExpiryDate", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.AspNetUsers", "ExpiryDate");
            DropColumn("dbo.AspNetUsers", "CreditCardNumber");
        }
    }
}
