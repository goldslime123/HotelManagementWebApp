namespace HotelManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PaymentandFeedback : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AspNetUsers", "TotalAmount", c => c.String());
            AddColumn("dbo.AspNetUsers", "TransactionDate", c => c.String());
            AddColumn("dbo.AspNetUsers", "Comment", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.AspNetUsers", "Comment");
            DropColumn("dbo.AspNetUsers", "TransactionDate");
            DropColumn("dbo.AspNetUsers", "TotalAmount");
        }
    }
}
