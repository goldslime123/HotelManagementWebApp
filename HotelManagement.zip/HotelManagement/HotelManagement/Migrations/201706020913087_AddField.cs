namespace HotelManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddField : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AspNetUsers", "RoomNumber", c => c.String());
            AddColumn("dbo.AspNetUsers", "RoomTypes", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.AspNetUsers", "RoomTypes");
            DropColumn("dbo.AspNetUsers", "RoomNumber");
        }
    }
}
