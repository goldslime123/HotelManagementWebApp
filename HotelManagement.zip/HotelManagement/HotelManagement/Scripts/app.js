﻿var ViewModel = function () {
    var self = this;
    self.products = ko.observableArray();
    self.error = ko.observable();
    self.details = ko.observable();

    //************  Remember to change the URI accordingly  **********************//
    var productsURI = 'http://localhost:50719/api/rooms/';

    //** this section contains all the AJAX call to the Web APIs **//
    // function to retrieve all products using AJAX call to web API

    function getAllProducts() {
        $.ajax({
            type: 'GET',
            url: productsURI,
            dataType: 'json',
            contentType: 'application/json',
            success: function (data) {
                self.products(data);
            },
            error: function (err) {
                alert("Error: " + err.status + " " + err.statusText);
            }
        });
    };
    // end of function to retrieve all products

    // get details of record with reference to the racket id
    self.getProductDetails = function (item) {
        $.ajax({
            type: 'GET',
            url: productsURI + item.Id,
            dataType: 'json',
            contentType: 'application/json',
            success: function (data) {
                self.details(data);
            },
            error: function (err) {
                alert("Error: " + err.status + " " + err.statusText);
            }
        });
    }

    // end of function to get details of a product

    self.updateImage = ko.observable();


    self.newProduct = {
        Id: ko.observable(),
        RoomNumber: ko.observable(),
        RoomTypes: ko.observable(),
        RoomStatus: ko.observable(),
        Price: ko.observable(),
        CoverImage: ko.observable(),
        Description: ko.observable(),
        MaxAdults: ko.observable(),
        MaxChildren: ko.observable()

       
    };



    /** this section is for file upload **/

    var FileModel = function (name, src, binary) {
        var self = this;
        this.name = name;
        this.src = src;
    };


    self.files = ko.observableArray(); // array to store files shown
    self.fileSelect = function (elemet, event) {

        var files = event.target.files; // FileList object from file upload
        var f = files[0]; // we are only interested in the first and only one file
        var reader = new FileReader();

        self.files.removeAll(); // clear the array, so that we can add the new file selected and display in the view
        reader.onload = (function (theFile) {
            return function (e) {
                self.files.push(new FileModel(escape(theFile.name), e.target.result)); // add to the array, file name and the binary data of the image file
                self.newProduct.CoverImage(e.target.result);
            };
        })(f);

        // Read in the image file as a data URL.
        reader.readAsDataURL(f);
    };

    self.updatefiles = ko.observableArray(); // array to store files shown
    self.updatefileSelect = function (elemet, event) {
        var updatefiles = event.target.files; // FileList object from file upload
        var f = updatefiles[0]; // we are only interested in the first and only one file
        var reader = new FileReader();

        self.updatefiles.removeAll(); // clear the array, so that we can add the new file selected and display in the view
        reader.onload = (function (theFile) {
            return function (e) {
                self.updatefiles.push(new FileModel(escape(theFile.name), e.target.result)); // add to the array, file name and the binary data of the image file
                self.updateImage(e.target.result);
            };
        })(f);

        // Read in the image file as a data URL.
        reader.readAsDataURL(f);
    };

    /** end of section for file upload **/


    // start of the function to save the new shoe record to database via Web API

    self.addProduct = function () {
        var aProduct = {
            Id: self.newProduct.Id(), // auto number field
            RoomNumber: self.newProduct.RoomNumber(),
            RoomTypes: self.newProduct.RoomTypes(),
            RoomStatus: self.newProduct.RoomStatus(),
            Price: self.newProduct.Price(),
            CoverImage: self.newProduct.CoverImage().replace('data:image/jpeg;base64,', ''),
            Description: self.newProduct.Description(),
            MaxAdults: self.newProduct.MaxAdults(),
            MaxChildren: self.newProduct.MaxChildren()
           
        };

        $.ajax({
            type: 'POST',
            url: productsURI,
            data: JSON.stringify(aProduct),
            dataType: 'json',
            contentType: 'application/json',
            success: function (data) {
                self.products.push(data);
                alert("Record created successfully!");
            },
            error: function (err) {
                alert("Error: " + err.status + " " + err.statusText);
            }
        });
    };
    // end of the function to save the new product record to database**/


    self.saveProduct = function () {
        if (self.updatefiles().length == 0)  // CoverImage is not changed
        {
            self.updateImage(self.details().CoverImage);
        }

        var updateProduct = {
            Id: self.details().Id,
            RoomNumber: self.details().RoomNumber,
            RoomTypes: self.details().RoomTypes,
            RoomStatus: self.details().RoomStatus,
            Price: self.details().Price,

            CoverImage: self.updateImage().replace('data:image/jpeg;base64,', ''),
            Description: self.details().Description,
            MaxAdults: self.details().MaxAdults,
            MaxChildren: self.details().MaxChildren
           

        };

        $.ajax({
            type: 'PUT',
            url: productsURI + updateProduct.Id,
            data: JSON.stringify(updateProduct),
            dataType: 'json',
            contentType: 'application/json',
            success: function (data) {
                self.products.replace(data);
                alert("Record updated successfully!");
            },
            error: function (err) {
                alert("Error: " + err.status + " " + err.statusText);
            }
        });
    };
    // end of method to save the updated product details

    // remove record from database using web api
    self.removeProduct = function () {
        var theProduct = {
            Id: self.details().Id,
            RoomNumber: self.details().RoomNumber,
            RoomTypes: self.details().RoomTypes,
            RoomStatus: self.details().RoomStatus,
            Price: self.details().Price,
            CoverImage: self.details().CoverImage,
            Description: self.details().Description,
            MaxAdults: self.details().MaxAdults,
            MaxChildren: self.details().MaxChildren
            
        };

        if (confirm('Are you sure to delete "' + theProduct.Title + '"?')) {
            $.ajax({
                type: 'DELETE',
                url: productsURI + theProduct.Id,
                dataType: 'json',
                contentType: 'application/json',
                success: function (data) {
                    self.products.remove(theProduct);
                    alert("Record has been deleted!");
                },
                error: function (err) {
                    alert("Error: " + err.status + " " + err.statusText);
                }
            });
        };
    }
    // end of method to remove the selected product

    // search at client side
    self.searchString = ko.observable();
    self.searchProducts = ko.computed(function () {
        if (!self.searchString()) {
            return self.products();
        } else {
            return ko.utils.arrayFilter(self.products(), function (product) {
                return ko.utils.stringStartsWith(product.RoomNumber.toUpperCase(), self.searchString().toUpperCase());
            });
        }
    });
    // end of search at client side

    // Fetch the initial data

    self.cart = ko.observableArray();

    self.addToCart = function (item) {
        self.cart.push(item);
    }

    self.addToCartDetails = function () {
        self.cart.push(self.details());
    }

    self.total = ko.computed(function () {
        var total = 0;
        for (var p = 0; p < self.cart().length; ++p) {
            total += self.cart()[p].Price;
        }
        return total;
    });

    //** this is the end of the section contains all the AJAX call to the Web APIs **//

    getAllProducts();

};

ko.applyBindings(new ViewModel());