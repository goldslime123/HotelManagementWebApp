﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HotelManagement.Models;

namespace HotelManagement.Controllers
{
    public class HousekeepingReportsController : Controller
    {
        private HotelReportDataEntities db = new HotelReportDataEntities();

        // GET: HousekeepingReports
        public ActionResult Index()
        {
            return View(db.HousekeepingReports.ToList());
        }

        // GET: HousekeepingReports/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HousekeepingReport housekeepingReport = db.HousekeepingReports.Find(id);
            if (housekeepingReport == null)
            {
                return HttpNotFound();
            }
            return View(housekeepingReport);
        }

        // GET: HousekeepingReports/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: HousekeepingReports/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "StaffID,TypesOfDuty,Daily,Weekly,Monthly")] HousekeepingReport housekeepingReport)
        {
            if (ModelState.IsValid)
            {
                db.HousekeepingReports.Add(housekeepingReport);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(housekeepingReport);
        }

        // GET: HousekeepingReports/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HousekeepingReport housekeepingReport = db.HousekeepingReports.Find(id);
            if (housekeepingReport == null)
            {
                return HttpNotFound();
            }
            return View(housekeepingReport);
        }

        // POST: HousekeepingReports/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "StaffID,TypesOfDuty,Daily,Weekly,Monthly")] HousekeepingReport housekeepingReport)
        {
            if (ModelState.IsValid)
            {
                db.Entry(housekeepingReport).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(housekeepingReport);
        }

        // GET: HousekeepingReports/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HousekeepingReport housekeepingReport = db.HousekeepingReports.Find(id);
            if (housekeepingReport == null)
            {
                return HttpNotFound();
            }
            return View(housekeepingReport);
        }

        // POST: HousekeepingReports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            HousekeepingReport housekeepingReport = db.HousekeepingReports.Find(id);
            db.HousekeepingReports.Remove(housekeepingReport);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
