﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Windows.Forms;
using System.Web.Security;

namespace HotelManagement.Controllers
{
    public class HouseKeepingController : Controller
    {

        private ApplicationDbContext context;

        /**************************************** IN MAINTENANCE
        //Search Page
        public ActionResult SearchPage()
        {
            return View("SearchStaff");
        }
        //Search Function
        public ActionResult SearchStaff(string query)
        {
            var user = from u in db.AspNetUsers
                           select u;

            if (!string.IsNullOrEmpty(query))
            {
                user = user.Where(s => s.Id.Contains(query));
            }

            return View(user);
        }
        */


        //VM:
        private HotelModelEntities db = new HotelModelEntities();


        public HouseKeepingController()
        {
            context = new ApplicationDbContext();
        }



        //*********************************************************************************READ/RETRIEVE
        // GET: HouseKeeping//Retrieve
        /////////////////////////////////////////////////////MODELS StaffViewModel
        public ActionResult StaffLists()
        {
            var allusers = context.Users;
            var staff = allusers.Where(x => x.Roles.Select(role => role.RoleId).Contains("bd5ab7e4-29c7-4b02-971c-379f9baa0e27") || x.Roles.Select(role => role.RoleId).Contains("e7b0bf3d-cb51-41d9-be55-edb8c25a969f")).ToList();

            var staffvm = staff.Select(user => new AddStaffViewModels
            {
                Id = user.Id,
                UserName = user.UserName,
                FirstName = user.FirstName,
                LastName = user.LastName,
                DOB = user.DOB,
                CreditCardNumber = user.CreditCardNumber,
                HomeAddress = user.HomeAddress,
                PhoneNumber = user.PhoneNumber,
                DutyTypes = user.DutyTypes

            }).ToList();
            var model = new GroupedStaffViewModel { Staff = staffvm };

            return View(model);
        }
        /////////////////////////////////////////////////MODELS StaffViewModel



        ///*********************************************CREATE, this might be redundant as we're doing with guest ASP.user
        ///****************************************************So they will have to sign up through the register page and be assigned later on
        ///****************************************It is needed to be this way because it is the one way available for account creation in mvc
        public ActionResult AddStaff()
        {
            return View();
        }


        // GET Delete/id
        /********Direct POSTING is enough
        public ActionResult DeleteStaff(string id)
        {
            if(id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AspNetUser users = db.AspNetUsers.Find(id);
            if(users == null)
            {
                return HttpNotFound();
            }
            return View(users);
        }
        */
        // Delete id *************************************************************************DELETE
        [Authorize(Roles = "Management, Admin")]
        public ActionResult DeleteStaff(string Id)
        {
            AspNetUser user = db.AspNetUsers.Find(Id);
            db.AspNetUsers.Remove(user);
            db.SaveChanges();
            MessageBox.Show("Successfully Deleted from Database");
            return RedirectToAction("StaffLists", "HouseKeeping");
        }



        //****************************************************************EDIT/UPDATE Staff Information 
        [Authorize(Roles = "Management, Admin")]
        public ActionResult EditStaff(string Id)
        {
            if (Id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AspNetUser user = db.AspNetUsers.Find(Id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, Management")]
        public ActionResult EditStaff([Bind(Include =
"Id, PasswordHash, SecurityStamp, UserName, FirstName, LastName, Email, DOB, CreditCardNumber, HomeAddress, PhoneNumber, DutyTypes")] AspNetUser user)
        {
            if (ModelState.IsValid)
            {
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                MessageBox.Show("Successfully Updated");
                return RedirectToAction("StaffLists", "HouseKeeping");
            }
            return View(user);
        }
    }
}