﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HotelManagement.Models;

namespace HotelManagement.Controllers
{
    public class AllRoomsReportsController : Controller
    {
        private HotelReportDataEntities db = new HotelReportDataEntities();

        // GET: AllRoomsReports
        public ActionResult Index()
        {
            return View(db.AllRoomsReports.ToList());
        }

        // GET: AllRoomsReports/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AllRoomsReport allRoomsReport = db.AllRoomsReports.Find(id);
            if (allRoomsReport == null)
            {
                return HttpNotFound();
            }
            return View(allRoomsReport);
        }

        // GET: AllRoomsReports/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AllRoomsReports/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "GuestID,RoomNumber,TypesOfRooms,FirstName,LastName,NumOfAdults,NumOfChildren,Date")] AllRoomsReport allRoomsReport)
        {
            if (ModelState.IsValid)
            {
                db.AllRoomsReports.Add(allRoomsReport);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(allRoomsReport);
        }

        // GET: AllRoomsReports/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AllRoomsReport allRoomsReport = db.AllRoomsReports.Find(id);
            if (allRoomsReport == null)
            {
                return HttpNotFound();
            }
            return View(allRoomsReport);
        }

        // POST: AllRoomsReports/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "GuestID,RoomNumber,TypesOfRooms,FirstName,LastName,NumOfAdults,NumOfChildren,Date")] AllRoomsReport allRoomsReport)
        {
            if (ModelState.IsValid)
            {
                db.Entry(allRoomsReport).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(allRoomsReport);
        }

        // GET: AllRoomsReports/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AllRoomsReport allRoomsReport = db.AllRoomsReports.Find(id);
            if (allRoomsReport == null)
            {
                return HttpNotFound();
            }
            return View(allRoomsReport);
        }

        // POST: AllRoomsReports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            AllRoomsReport allRoomsReport = db.AllRoomsReports.Find(id);
            db.AllRoomsReports.Remove(allRoomsReport);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
