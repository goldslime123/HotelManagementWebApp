﻿using System;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using HotelManagement.Models;
using System.Windows.Forms;
using Microsoft.AspNet.Identity.EntityFramework;

namespace HotelManagement.Controllers
{
    [Authorize]
    public class BookingController : Controller
    {

        private ApplicationSignInManager _signInManager;
        private ApplicationUserManager _userManager;
        private ApplicationDbContext context;

        public BookingController()
        {
            context = new ApplicationDbContext();
        }

        public BookingController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set
            {
                _signInManager = value;
            }
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }


        // GET: /Booking/CheckinGuest
        [AllowAnonymous]
        public ActionResult Checkin()
        {
            ViewBag.Name = new SelectList(context.Roles.ToList(), "Name", "Name");
            return View();
        }


        // POST: /Booking/CheckinGuest
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Checkin(CheckinViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser { UserName= model.UserName, Checkin = model.Checkin, Checkout = model.Checkout, FirstName = model.FirstName, LastName = model.LastName,
                    NumberofAdults = model.NumberofAdults, NumberofChildren = model.NumberofChildren, PhoneNumber= model.PhoneNumber,
                    Email = model.Email, HomeAddress = model.HomeAddress,CreditCardNumber=model.CreditCardNumber,ExpiryDate=model.ExpiryDate,TypesofPayment=model.TypesofPayment,TotalAmount=model.TotalAmount,TransactionDate=model.TransactionDate, RoomNumber=model.RoomNumber, RoomTypes=model.RoomTypes };
                var result = await UserManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {


                    //Assign Role to user Here
                    await UserManager.AddToRoleAsync(user.Id, model.Role);
                    //Ends Here

                    string text = "Suceesfully added";
                    MessageBox.Show(text);
                }
                AddErrors(result);

            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }
        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        public ActionResult GuestsList()
        {
            var allusers = context.Users;
            var guest = allusers.Where(x => x.Roles.Select(role => role.RoleId).Contains("0afee83b-3850-4782-bd78-c76d79b7cb0d")).ToList();

            var guestvm = guest.Select(user => new CheckinViewModel
            {
                UserName = user.UserName,
                Checkin = user.Checkin,
                Checkout = user.Checkout,
                FirstName = user.FirstName,
                LastName = user.LastName,
                NumberofAdults = user.NumberofAdults,
                NumberofChildren = user.NumberofChildren,
                PhoneNumber = user.PhoneNumber,
                Email = user.Email,
                HomeAddress = user.HomeAddress,
                TypesofPayment=user.TypesofPayment,
                CreditCardNumber = user.CreditCardNumber,
                ExpiryDate = user.ExpiryDate,
                RoomNumber=user.RoomNumber,
                RoomTypes = user.RoomTypes

            }).ToList();
            var model = new GroupedUserViewModel { Guest = guestvm };

            return View(model);
        }

        public ActionResult PaymentDetails()
        {
            var allusers = context.Users;
            var guest = allusers.Where(x => x.Roles.Select(role => role.RoleId).Contains("0afee83b-3850-4782-bd78-c76d79b7cb0d")).ToList();

            var guestvm = guest.Select(user => new CheckinViewModel
            {
                UserName = user.UserName,
                
                TypesofPayment = user.TypesofPayment,
                TotalAmount=user.TotalAmount,
                CreditCardNumber = user.CreditCardNumber,
                ExpiryDate = user.ExpiryDate,
                TransactionDate=user.TransactionDate

            }).ToList();
            var model = new GroupedUserViewModel { Guest = guestvm };

            return View(model);
        }

        public ActionResult Feedback()
        {
            var allusers = context.Users;
            var guest = allusers.Where(x => x.Roles.Select(role => role.RoleId).Contains("0afee83b-3850-4782-bd78-c76d79b7cb0d")).ToList();

            var guestvm = guest.Select(user => new FeedbackViewModel
            {
                UserName = user.UserName,
               Comment=user.Comment

            }).ToList();


            var model = new GroupedUserViewModel1 { Guest = guestvm };

            return View(model);
        }

        


      

    }
}