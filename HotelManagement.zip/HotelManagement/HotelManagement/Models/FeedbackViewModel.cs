﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace HotelManagement.Models
{

    public class GroupedUserViewModel1
    {
        public List<FeedbackViewModel> Guest { get; set; }

    }
    public class FeedbackViewModel
    {

        [Required]
        [Display(Name = "UserName")]
        public string UserName { get; set; }


        [Required]
        [Display(Name = "Comment")]
        public string Comment { get; set; }

        
    }
}