﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace HotelManagement.Models
{

    public class GroupedUserViewModel4
    {
        public List<CheckinViewModel> Guest { get; set; }

    }
    public class CheckoutViewModel
    {
        //Role Name
        public string Role { get; set; }

        //---

        [Required]
        [Display(Name = "Check in Date")]
        public string Checkin { get; set; }

        [Required]
        [Display(Name = "Check Out Date")]
        public string Checkout { get; set; }

        [Required]

        [StringLength(20, MinimumLength = 2)]
        [Display(Name = "UserName")]
        public string UserName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Number of Adults")]
        public int NumberofAdults { get; set; }

        [Required]
        [Display(Name = "Number of Children")]
        public int NumberofChildren { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Home Address")]
        public string HomeAddress { get; set; }
        //---

        [Required]
        [Display(Name = "Types of Payment")]
        public string TypesofPayment { get; set; }

        [Required]
        [Display(Name = "Total Amount")]
        public string TotalAmount { get; set; }

        [Required]
        [Display(Name = "Credit Card Number")]
        public string CreditCardNumber { get; set; }


        [Required]
        [Display(Name = "Expiry Date")]
        public string ExpiryDate { get; set; }

 

        [Required]
        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; }


        [Required]
        [Display(Name = "Room Types")]
        public string RoomTypes { get; set; }

        [Required]
        [Display(Name = "Comment")]
        public string Comment { get; set; }




    }


}