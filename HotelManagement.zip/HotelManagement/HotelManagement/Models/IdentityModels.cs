﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace HotelManagement.Models
{

    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {

      

    

        //Guest Details

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int NumberofAdults { get; set; }

        public int NumberofChildren { get; set; }

        public string HomeAddress { get; set; }

        public string TypesofPayment { get; set; }

        public string Checkin { get; set; }
        public string Checkout { get; set; }

        //Payment 
        public string TotalAmount { get; set; }
        public string TransactionDate { get; set; }
        public string CreditCardNumber { get; set; }
        public string ExpiryDate { get; set; }


        //staff
        public string RoomNumber { get; set; }
        public string RoomTypes { get; set; }

        public string DOB { get; set; }
        public int BankNumber { get; set; }
        public string DutyTypes { get; set; }

        //Feedback
        public string Comment { get; set; }


        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
    }
}