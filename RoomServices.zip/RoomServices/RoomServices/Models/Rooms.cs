﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RoomServices.Models
{
    public class Rooms
    {
        public int Id { get; set; }

        [Required]
        public string RoomNumber { get; set; }
        public string RoomTypes { get; set; }
        public string RoomStatus { get; set; }
        public double Price { get; set; }
        public byte[] CoverImage { get; set; }
        public string Description { get; set; }
        public int MaxAdults { get; set; }
        public int MaxChildren { get; set; }
    }
}