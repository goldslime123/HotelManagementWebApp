﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using RoomServices.Models;

namespace RoomServices.Controllers
{
    public class RoomsController : ApiController
    {
        private RoomServicesContext db = new RoomServicesContext();

        // GET: api/Rooms
        public IQueryable<Rooms> GetRooms()
        {
            return db.Rooms;
        }

        // GET: api/Rooms/5
        [ResponseType(typeof(Rooms))]
        public async Task<IHttpActionResult> GetRooms(int id)
        {
            Rooms rooms = await db.Rooms.FindAsync(id);
            if (rooms == null)
            {
                return NotFound();
            }

            return Ok(rooms);
        }

        // PUT: api/Rooms/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutRooms(int id, Rooms rooms)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != rooms.Id)
            {
                return BadRequest();
            }

            db.Entry(rooms).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RoomsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Rooms
        [ResponseType(typeof(Rooms))]
        public async Task<IHttpActionResult> PostRooms(Rooms rooms)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Rooms.Add(rooms);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = rooms.Id }, rooms);
        }

        // DELETE: api/Rooms/5
        [ResponseType(typeof(Rooms))]
        public async Task<IHttpActionResult> DeleteRooms(int id)
        {
            Rooms rooms = await db.Rooms.FindAsync(id);
            if (rooms == null)
            {
                return NotFound();
            }

            db.Rooms.Remove(rooms);
            await db.SaveChangesAsync();

            return Ok(rooms);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RoomsExists(int id)
        {
            return db.Rooms.Count(e => e.Id == id) > 0;
        }
    }
}