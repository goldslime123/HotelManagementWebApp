namespace RoomServices.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using RoomServices.Models;
    using System.IO;


    internal sealed class Configuration : DbMigrationsConfiguration<RoomServices.Models.RoomServicesContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }
        //Open file into a filestream and read data in a byte array.
        byte[] ReadFile(string sPath)
        {
            //Initialize byte array with a null value initially.
            byte[] data = null;

            //Use FileInfo object to get file size.
            FileInfo fInfo = new FileInfo(sPath);
            long numBytes = fInfo.Length;

            //Open FileStream to read file
            FileStream fStream = new FileStream(sPath, FileMode.Open,
            FileAccess.Read);

            //Use BinaryReader to read file stream into byte array.
            BinaryReader br = new BinaryReader(fStream);

            //When you use BinaryReader, you need to 

            //supply number of bytes to read from file.
            data = br.ReadBytes((int)numBytes);
            return data;
        }

        protected override void Seed(RoomServices.Models.RoomServicesContext context)
        {
            context.Rooms.AddOrUpdate(x => x.Id,
   new Rooms() { Id = 1, RoomNumber = "R1", RoomTypes = "1 Room", RoomStatus = "Vacant", Price = 40, CoverImage = ReadFile("C:\\Users\\USER\\Desktop\\RoomServices\\RoomServices\\Images\\1room.jpg"), Description = "Paperback", MaxAdults = 2, MaxChildren = 2 });
        }
    }
}
