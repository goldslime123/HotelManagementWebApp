namespace RoomServices.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Rooms",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        RoomNumber = c.String(nullable: false),
                        RoomTypes = c.String(),
                        RoomStatus = c.String(),
                        Price = c.Double(nullable: false),
                        CoverImage = c.Binary(),
                        Description = c.String(),
                        MaxAdults = c.Int(nullable: false),
                        MaxChildren = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Rooms");
        }
    }
}
