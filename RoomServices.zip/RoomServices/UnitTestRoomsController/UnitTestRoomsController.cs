﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RoomServices.Controllers;
using System.Linq;
using RoomServices.Models;
using System.Threading.Tasks;
using System.Web.Http.Results;
using System.Net;
using System;

namespace UnitTestRoomsController
{
    [TestClass]
    public class UnitTestRoomsController
    {
        [TestMethod]
        public void GetAllRooms_ShouldReturnAllRooms()
        {
            int NumberOfRecords = 4; // when new record exceeds the actual record in the database
            var controller = new RoomsController();

            var result = controller.GetRooms() as IQueryable<Rooms>;
            Assert.IsNotNull(result);
            Assert.AreEqual(NumberOfRecords, result.Count());
        }


        [TestMethod]
        public async Task GetRoom_ShouldReturnRoomWithSameID()
        {
            int IDtoRetrieve = 1;
            var controller = new RoomsController();
            var result = await controller.GetRooms(IDtoRetrieve) as OkNegotiatedContentResult<Rooms>;
            Assert.IsNotNull(result);
            Assert.AreEqual(IDtoRetrieve, result.Content.Id);
        }



        [TestMethod]
        public async Task DeleteRoom_ShouldDeleteRoomWithSameID()
        {
            int IDtobeDeleted = 8; // need to change after each delete test
            var controller = new RoomsController();
            var result = await controller.DeleteRooms(IDtobeDeleted) as OkNegotiatedContentResult<Rooms>;

            Assert.IsNotNull(result);
            Assert.AreEqual(IDtobeDeleted, result.Content.Id);
        }


        [TestMethod]
        public async Task DeleteRoom_ShouldNotDeletetheRoom()
        {
            int IDtobeDeleted = 1000; // there is no room with id="1000"
            var controller = new RoomsController();
            var result = await controller.DeleteRooms(IDtobeDeleted) as OkNegotiatedContentResult<Rooms>;

            Assert.IsNotNull(result);
            Assert.AreEqual(IDtobeDeleted, result.Content.Id);
        }
    }
}
